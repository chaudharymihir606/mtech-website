# M.Tech Ahmedabad — website files

Rebuilt and hardened version of the 5-page site. Design unchanged.

## What to upload

Upload **everything in this folder** to your hosting root (the folder that
holds the site). Keep the folder structure exactly as it is.

```
index.html          <- home page (this is what visitors see first)
products.html
services.html
contact.html
about.html
home.html           <- redirects old /home.html links to /
404.html
logoo.png           <- ⚠️ YOU MUST ADD THIS FILE (see below)
assets/
  menu.js
  products.js
  contact.js
robots.txt
sitemap.xml
.well-known/security.txt

# pick the ONE that matches your host, ignore the rest:
.htaccess            -> Apache / cPanel / Hostinger / most shared hosting
_headers,_redirects  -> Netlify, Cloudflare Pages
vercel.json          -> Vercel
nginx-security.conf  -> nginx (include it inside your server { } block)
```

## ⚠️ logoo.png

The logo file was never uploaded, so it is not in this folder. Put your
`logoo.png` in the same folder as `index.html`. Until you do, the header
shows a text logo ("M.Tech") instead — nothing breaks either way.

## Still to confirm

1. **Full street address + PIN code.** Not available anywhere, so the site
   says only "M.Tech Ahmedabad, Ahmedabad, Gujarat". Search `TODO` in the
   HTML files to find every place it needs to go.
2. **Domain.** All canonical/OG/sitemap URLs assume
   `https://www.mtechahmedabad.com`. Change them if that is wrong.
3. **Google Maps link.** The site had two different links. Everything now
   uses `maps.app.goo.gl/6pT45zfBXSbPrRMz9` (the one used on 4 of 5 pages).
4. **Content claims** worth checking: the "12+ / 6 / 9 / 2026" numbers on
   the About page, product prices on the Products page, and the FAQ line
   about a service warranty.

## Security notes

- Every page sends a strict Content-Security-Policy. `script-src 'self'`
  means no inline script and no inline `onclick`/`onerror` can ever run —
  that is why all JavaScript lives in `assets/`.
- `frame-ancestors` / `X-Frame-Options` cannot be set from an HTML file.
  They are in the server config files above. **Upload the right one or
  clickjacking protection is missing.**
- Product images are hotlinked from ~10 other websites, so the policy has
  to allow `img-src https:`. Downloading those images into your own folder
  would be safer and faster.
- Google Fonts still load from Google.
- No site is "unhackable". The rest depends on your hosting: HTTPS on,
  software updated, a strong password and two-factor authentication.

## Editing later

- The CSS lives inside each page in a `<style>` block — safe to edit.
- The JavaScript lives in `assets/` — if you edit it, keep it in those
  files. Moving it back inside the HTML will break it, because the
  Content-Security-Policy blocks inline scripts on purpose.
