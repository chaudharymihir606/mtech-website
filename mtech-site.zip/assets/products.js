/* =====================================================
   M.Tech Ahmedabad - product filter and search
   Loaded as an external file so the page can use a strict
   Content-Security-Policy (script-src 'self'), which blocks
   every inline script and every inline event handler.
===================================================== */

(function () {
    "use strict";

    /* Only these category values are ever accepted - anything else
       coming from the URL is ignored. */
    var ALLOWED_CATEGORIES = ["all", "laptop", "desktop", "cctv", "printer", "accessory"];

    var filterButtons = document.querySelectorAll(".filter-btn");
    var productCards  = document.querySelectorAll(".card");
    var searchInput   = document.getElementById("searchInput");
    var noProducts    = document.getElementById("noProducts");
    var exploreButton = document.getElementById("exploreAll");

    if (!filterButtons.length || !productCards.length || !searchInput || !noProducts) {
        return;
    }

    var selectedCategory = "all";


    /* ---------- Searchable text, built once (never from innerText,
                  so button labels can't pollute the search) ---------- */

    var cards = [];

    productCards.forEach(function (card) {
        var name = card.getAttribute("data-name") || "";
        var keywords = card.getAttribute("data-keywords") || "";
        var categoryLabel = card.querySelector(".category");
        var description = card.querySelector(".description");

        cards.push({
            el: card,
            category: card.getAttribute("data-category") || "",
            text: (
                name + " " +
                keywords + " " +
                (categoryLabel ? categoryLabel.textContent : "") + " " +
                (description ? description.textContent : "")
            ).toLowerCase().replace(/\s+/g, " ")
        });
    });


    /* ---------- Filtering ---------- */

    function filterProducts() {
        var searchText = searchInput.value.toLowerCase().trim();
        var visible = 0;

        cards.forEach(function (item) {
            var categoryMatch =
                selectedCategory === "all" ||
                item.category === selectedCategory;

            var searchMatch =
                searchText === "" ||
                item.text.indexOf(searchText) !== -1;

            if (categoryMatch && searchMatch) {
                item.el.classList.remove("hide");
                visible++;
            } else {
                item.el.classList.add("hide");
            }
        });

        noProducts.style.display = (visible === 0) ? "block" : "none";
    }


    function setCategory(category) {
        if (ALLOWED_CATEGORIES.indexOf(category) === -1) {
            category = "all";
        }

        selectedCategory = category;

        filterButtons.forEach(function (button) {
            var isActive = button.getAttribute("data-category") === category;
            button.classList.toggle("active", isActive);
            button.setAttribute("aria-pressed", isActive ? "true" : "false");
        });

        filterProducts();
    }


    /* ---------- Events ---------- */

    filterButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            setCategory(button.getAttribute("data-category"));
        });
    });

    searchInput.addEventListener("input", filterProducts);

    if (exploreButton) {
        exploreButton.addEventListener("click", function () {
            searchInput.value = "";
            setCategory("all");
            document.getElementById("products").scrollIntoView({ behavior: "smooth" });
        });
    }


    /* ---------- Read ?category= and ?q= from the URL (whitelisted) ---------- */

    function applyUrlParameters() {
        var params;

        try {
            params = new URLSearchParams(window.location.search);
        } catch (error) {
            return false;
        }

        var category = (params.get("category") || "").toLowerCase().trim();
        var query = (params.get("q") || "");

        /* Strip anything that is not a plain letter, digit, space or
           basic punctuation, then cap the length. */
        query = query.replace(/[^a-zA-Z0-9 .,'&+-]/g, "").trim().slice(0, 60);

        var used = false;

        if (ALLOWED_CATEGORIES.indexOf(category) !== -1 && category !== "all") {
            setCategory(category);
            used = true;
        }

        if (query) {
            searchInput.value = query;
            filterProducts();
            used = true;
        }

        return used;
    }

    var cameFromLink = applyUrlParameters();

    filterProducts();

    if (cameFromLink) {
        window.setTimeout(function () {
            document.getElementById("products").scrollIntoView({ behavior: "smooth" });
        }, 120);
    }
})();
