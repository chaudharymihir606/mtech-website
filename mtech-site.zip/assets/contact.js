/* =====================================================
   M.Tech Ahmedabad - enquiry form
   Loaded as an external file so the page can use a strict
   Content-Security-Policy (script-src 'self'), which blocks
   every inline script and every inline event handler.
===================================================== */

(function () {
    "use strict";

    var WHATSAPP_NUMBER = "917383037521";

    var form      = document.getElementById("contactForm");
    var errorBox  = document.getElementById("formError");
    var toast     = document.getElementById("toast");

    if (!form || !errorBox) { return; }

    var fields = {
        name:     document.getElementById("name"),
        phone:    document.getElementById("phone"),
        email:    document.getElementById("email"),
        interest: document.getElementById("interest"),
        message:  document.getElementById("message"),
        company:  document.getElementById("company")
    };

    var toastTimer = null;


    /* ---------- Toast ---------- */

    function showToast(text) {
        if (!toast) { return; }

        toast.textContent = text;
        toast.classList.add("show");

        window.clearTimeout(toastTimer);
        toastTimer = window.setTimeout(function () {
            toast.classList.remove("show");
        }, 3500);
    }


    /* ---------- Input cleaning ----------
       Removes control characters, zero-width / bidi characters and
       line-separator characters that can be used to disguise text,
       collapses whitespace and caps the length. */

    function clean(value, maxLength, keepLineBreaks) {
        var text = String(value === null || value === undefined ? "" : value);

        text = text.replace(
            /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u00AD\u200B-\u200F\u2028\u2029\u202A-\u202E\u2060-\u2064\u2066-\u206F\uFEFF]/g,
            ""
        );

        if (keepLineBreaks) {
            text = text.replace(/\r\n?/g, "\n").replace(/\n{3,}/g, "\n\n");
            text = text.replace(/[ \t]{2,}/g, " ");
        } else {
            text = text.replace(/\s+/g, " ");
        }

        return text.trim().slice(0, maxLength);
    }


    /* ---------- Validation ---------- */

    function isValidPhone(phone) {
        var digits = phone.replace(/\D/g, "");
        return digits.length >= 7 && digits.length <= 15;
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(email);
    }

    function setInvalid(field, invalid) {
        if (!field) { return; }
        if (invalid) {
            field.setAttribute("aria-invalid", "true");
        } else {
            field.removeAttribute("aria-invalid");
        }
    }

    function showError(message, field) {
        errorBox.textContent = message;
        errorBox.classList.add("show");
        showToast(message);

        if (field) {
            setInvalid(field, true);
            field.focus();
        }
    }

    function clearErrors() {
        errorBox.textContent = "";
        errorBox.classList.remove("show");
        setInvalid(fields.name, false);
        setInvalid(fields.phone, false);
        setInvalid(fields.email, false);
        setInvalid(fields.message, false);
    }


    /* ---------- Message text ---------- */

    function buildMessageText(data) {
        var lines = [];

        lines.push("New enquiry from the M.Tech website");
        lines.push("");
        lines.push("Name: " + data.name);
        lines.push("Phone: " + data.phone);

        if (data.email)    { lines.push("Email: " + data.email); }
        if (data.interest) { lines.push("Interested in: " + data.interest); }

        lines.push("");
        lines.push("Message:");
        lines.push(data.message);

        return lines.join("\n");
    }


    /* ---------- Submit ----------
       There is no server behind this form. Submitting opens WhatsApp
       with the message already typed in; the visitor taps Send once. */

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        clearErrors();

        /* Honeypot - only bots fill this in. Fail silently. */
        if (fields.company && clean(fields.company.value, 50)) {
            showToast("Thanks, your message has been noted.");
            return;
        }

        var data = {
            name:     clean(fields.name ? fields.name.value : "", 60),
            phone:    clean(fields.phone ? fields.phone.value : "", 20),
            email:    clean(fields.email ? fields.email.value : "", 80),
            interest: clean(fields.interest ? fields.interest.value : "", 30),
            message:  clean(fields.message ? fields.message.value : "", 700, true)
        };

        if (!data.name) {
            showError("Please enter your name.", fields.name);
            return;
        }

        if (data.name.length < 2) {
            showError("Please enter your full name.", fields.name);
            return;
        }

        if (!data.phone) {
            showError("Please enter your phone number.", fields.phone);
            return;
        }

        if (!isValidPhone(data.phone)) {
            showError("Please enter a valid phone number (7 to 15 digits).", fields.phone);
            return;
        }

        if (data.email && !isValidEmail(data.email)) {
            showError("Please enter a valid email address, or leave it empty.", fields.email);
            return;
        }

        if (!data.message) {
            showError("Please tell us about your requirement.", fields.message);
            return;
        }

        if (data.message.length < 5) {
            showError("Please add a little more detail to your message.", fields.message);
            return;
        }

        var url = "https://wa.me/" + WHATSAPP_NUMBER +
                  "?text=" + encodeURIComponent(buildMessageText(data));

        var opened = window.open(url, "_blank", "noopener,noreferrer");

        if (!opened) {
            showToast("Please allow pop-ups, or message us directly on WhatsApp.");
            return;
        }

        showToast("Opening WhatsApp with your message...");
        form.reset();
    });


    /* Clear the error as soon as the visitor starts fixing it. */

    form.addEventListener("input", function (event) {
        if (errorBox.classList.contains("show")) {
            setInvalid(event.target, false);
        }
    });
})();
