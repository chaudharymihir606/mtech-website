/* =====================================================
   M.Tech Ahmedabad - header, logo fallback and mobile menu
   Loaded as an external file so the page can use a strict
   Content-Security-Policy (script-src 'self'), which blocks
   every inline script and every inline event handler.
===================================================== */

(function () {
    "use strict";

    /* ---------- Logo fallback (if logoo.png is missing) ---------- */

    var logo = document.querySelector(".brand-logo");

    if (logo) {
        var markMissing = function () {
            document.documentElement.classList.add("no-logo");
        };
        logo.addEventListener("error", markMissing);
        if (logo.complete && logo.naturalWidth === 0) {
            markMissing();
        }
    }


    /* ---------- Mobile hamburger menu ---------- */

    var toggle = document.getElementById("menuToggle");
    var nav = document.getElementById("mainNav");

    if (!toggle || !nav) { return; }

    function setMenu(open) {
        nav.classList.toggle("open", open);
        toggle.classList.toggle("active", open);
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    }

    toggle.addEventListener("click", function (event) {
        event.stopPropagation();
        setMenu(!nav.classList.contains("open"));
    });

    nav.addEventListener("click", function (event) {
        if (event.target.tagName === "A") { setMenu(false); }
    });

    document.addEventListener("click", function (event) {
        if (nav.classList.contains("open") &&
            !nav.contains(event.target) &&
            !toggle.contains(event.target)) {
            setMenu(false);
        }
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape" && nav.classList.contains("open")) {
            setMenu(false);
            toggle.focus();
        }
    });

    window.addEventListener("resize", function () {
        if (window.innerWidth > 768 && nav.classList.contains("open")) {
            setMenu(false);
        }
    });
})();
